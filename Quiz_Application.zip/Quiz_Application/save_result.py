import start_quiz
def save_result():
    if start_quiz.total==0:
        print("No Result To Save")
        return
    with open("result.txt","a") as f:
        f.write(f"Name: {start_quiz.student_name}\n")
        f.write(f"Score: {start_quiz.score}/{start_quiz.total}\n")
        f.write("-"*20+"\n")
    print("Result Saved Successfully")
