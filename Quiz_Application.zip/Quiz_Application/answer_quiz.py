from questions import questions
import start_quiz
def answer_quiz():
    if start_quiz.student_name=="":
        print("Start Quiz First")
        return
    start_quiz.score=0
    start_quiz.total=len(questions)
    for q in questions:
        print("\n"+q["question"])
        for op in q["options"]:
            print(op)
        try:
            ans=input("Enter Answer (A/B/C/D): ").upper()
            if ans not in ["A","B","C","D"]:
                raise ValueError
            if ans==q["answer"]:
                start_quiz.score+=1
        except ValueError:
            print("Invalid Input")
