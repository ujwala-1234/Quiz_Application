from start_quiz import start
from view_questions import view_questions
from answer_quiz import answer_quiz
from check_score import check_score
from view_percentage import view_percentage
from save_result import save_result

while True:
    print("\n===== QUIZ APPLICATION =====")
    print("1. Start Quiz")
    print("2. View Questions")
    print("3. Answer Quiz")
    print("4. Check Score")
    print("5. View Percentage")
    print("6. Save Result")
    print("7. Exit")
    ch=input("Enter Choice: ")
    if ch=="1":
        start()
    elif ch=="2":
        view_questions()
    elif ch=="3":
        answer_quiz()
    elif ch=="4":
        check_score()
    elif ch=="5":
        view_percentage()
    elif ch=="6":
        save_result()
    elif ch=="7":
        print("Thank You")
        break
    else:
        print("Invalid Choice")
