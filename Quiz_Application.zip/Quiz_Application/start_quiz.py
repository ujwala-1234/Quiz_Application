student_name=""
score=0
total=0
def start():
    global student_name,score,total
    student_name=input("Enter Student Name: ")
    score=0
    total=0
    print("Quiz Started Successfully!")
