questions=[
{"question":"1. What is the capital of India?","options":["A. Delhi","B. Mumbai","C. Chennai","D. Kolkata"],"answer":"A"},
{"question":"2. Which keyword defines a function in Python?","options":["A. function","B. define","C. def","D. fun"],"answer":"C"},
{"question":"3. Which data type stores multiple values?","options":["A. int","B. float","C. list","D. bool"],"answer":"C"},
{"question":"4. Which loop is used in Python?","options":["A. for","B. while","C. Both","D. None"],"answer":"C"},
{"question":"5. Python is a ____ language.","options":["A. High Level","B. Low Level","C. Machine","D. Assembly"],"answer":"A"}
]
