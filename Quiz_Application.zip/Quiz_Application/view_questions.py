from questions import questions
def view_questions():
    for q in questions:
        print("\n"+q["question"])
        for op in q["options"]:
            print(op)
