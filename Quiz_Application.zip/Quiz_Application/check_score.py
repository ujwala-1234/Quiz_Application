import start_quiz
def check_score():
    print("Score:",start_quiz.score,"/",start_quiz.total)
