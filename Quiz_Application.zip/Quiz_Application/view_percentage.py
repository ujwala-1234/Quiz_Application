import start_quiz
def view_percentage():
    if start_quiz.total==0:
        print("No Quiz Attempted")
    else:
        p=(start_quiz.score/start_quiz.total)*100
        print("Percentage:",round(p,2),"%")
